package com.java.customer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerRewardProgramApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerRewardProgramApplication.class, args);
	}

}
