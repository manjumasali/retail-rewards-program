insert into customer(id, name) values (1, 'Manjunath');
insert into my_transaction(id, total, save_date, customer_id) values (1, 120,'2024-12-19', 1);